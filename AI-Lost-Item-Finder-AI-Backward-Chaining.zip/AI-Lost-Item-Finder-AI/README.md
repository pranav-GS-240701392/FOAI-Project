# AI Lost Item Finder — Symbolic AI

A standalone React + TypeScript mini-project demonstrating:
- Knowledge Representation
- First-Order Logic-inspired predicates
- Rule-Based Reasoning
- Backward Chaining
- Inference Engine
- Explanation Mechanism
- Candidate ranking

Run:
npm install
npm run dev

Main algorithm: Backward Chaining. The system starts from a candidate goal such as PossibleLocation(water_bottle,classroom), searches for rules that can prove it, creates sub-goals, and recursively checks facts.

This project intentionally does not claim to use machine learning, deep learning, computer vision, or an LLM.
